<footer>
			<div class="footer-col-left">
				<p>&copy; copyright 2015 EVENING SUCCESS</p>
			</div>
			
			<div class="footer-col-right">
				<ul class="social-media">
					<li><a href="https://fr.linkedin.com/" target="_blank"><img src="<?= get_template_directory_uri(); ?>/img/logo-linkedin.svg"></a></li>
					<li><a href="https://www.facebook.com/" target="_blank"><img src="<?= get_template_directory_uri(); ?>/img/logo-fb.svg"></a></li>
					<li><a href="https://plus.google.com/" target="_blank"><img src="<?= get_template_directory_uri(); ?>/img/logo-google.svg"></a></li>
					<li><a href="https://twitter.com/?lang=fr" target="_blank"><img src="<?= get_template_directory_uri(); ?>/img/logo-twitter.svg"></a></li>
				</ul>
			</div>
			
			<div class="clearer"></div>
		
		</footer>

	</body>
	
</html>